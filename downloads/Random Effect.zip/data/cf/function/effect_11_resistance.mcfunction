effect give @a[tag=11] resistance 30 2
schedule function cf:dore 6000t append

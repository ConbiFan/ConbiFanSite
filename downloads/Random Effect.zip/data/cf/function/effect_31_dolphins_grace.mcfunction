effect give @a[tag=31] dolphins_grace 30 2
schedule function cf:dore 6000t append

effect give @a[tag=30] dolphins_grace 30 2
schedule function dore 300s

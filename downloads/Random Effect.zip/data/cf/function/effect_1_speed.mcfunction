effect give @a[tag=1] speed 30 2
schedule function cf:dore 6000t append

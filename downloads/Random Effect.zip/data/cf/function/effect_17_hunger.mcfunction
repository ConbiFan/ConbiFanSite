effect give @a[tag=17] hunger 30 2
schedule function cf:dore 300s

effect give @a[tag=9] nausea 30 2
schedule function cf:dore 300s

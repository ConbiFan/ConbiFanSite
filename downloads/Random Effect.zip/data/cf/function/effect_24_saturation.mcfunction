effect give @a[tag=24] saturation 30 2
schedule function cf:dore 6000t append

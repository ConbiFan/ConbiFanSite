effect give @a[tag=23] saturation 30 2
schedule function cf:dore 300s

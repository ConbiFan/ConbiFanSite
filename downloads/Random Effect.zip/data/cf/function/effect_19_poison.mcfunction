effect give @a[tag=19] poison 30 2
schedule function cf:dore 6000t append

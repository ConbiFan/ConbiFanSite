effect give @a[tag=16] night_vision 30 2
schedule function cf:dore 6000t append

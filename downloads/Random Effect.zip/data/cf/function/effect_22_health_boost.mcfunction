effect give @a[tag=22] health_boost 30 2
schedule function cf:dore 6000t append

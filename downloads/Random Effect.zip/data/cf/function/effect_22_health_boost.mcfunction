effect give @a[tag=21] health_boost 30 2
schedule function cf:dore 300s

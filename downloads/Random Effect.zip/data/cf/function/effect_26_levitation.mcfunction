effect give @a[tag=26] levitation 30 2
schedule function cf:dore 6000t append

effect give @a[tag=25] levitation 30 2
schedule function cf:dore 300s

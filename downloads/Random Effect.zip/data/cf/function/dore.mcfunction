tag @a remove 1
tag @a remove 2
tag @a remove 3
tag @a remove 4
tag @a remove 5
tag @a remove 6
tag @a remove 7
tag @a remove 8
tag @a remove 9
tag @a remove 10
tag @a remove 11
tag @a remove 12
tag @a remove 13
tag @a remove 14
tag @a remove 15
tag @a remove 16
tag @a remove 17
tag @a remove 18
tag @a remove 19
tag @a remove 21
tag @a remove 22
tag @a remove 23
tag @a remove 24
tag @a remove 25
tag @a remove 26
tag @a remove 27
tag @a remove 28
tag @a remove 29
tag @a remove 30
tag @a remove 31
tag @a remove 32
tag @a remove 33
tag @a remove 34
tag @a remove 35
tag @a remove 36
tag @a remove 37
tag @a remove 38
tag @a remove 39
execute as @a store result score @s rand run random value 1..39
execute as @a if score @s rand matches 1 run tag @s add 1
execute as @a if score @s rand matches 2 run tag @s add 2
execute as @a if score @s rand matches 3 run tag @s add 3
execute as @a if score @s rand matches 4 run tag @s add 4
execute as @a if score @s rand matches 5 run tag @s add 5
execute as @a if score @s rand matches 6 run tag @s add 6
execute as @a if score @s rand matches 7 run tag @s add 7
execute as @a if score @s rand matches 8 run tag @s add 8
execute as @a if score @s rand matches 9 run tag @s add 9
execute as @a if score @s rand matches 10 run tag @s add 10
execute as @a if score @s rand matches 11 run tag @s add 11
execute as @a if score @s rand matches 12 run tag @s add 12
execute as @a if score @s rand matches 13 run tag @s add 13
execute as @a if score @s rand matches 14 run tag @s add 14
execute as @a if score @s rand matches 15 run tag @s add 15
execute as @a if score @s rand matches 16 run tag @s add 16
execute as @a if score @s rand matches 17 run tag @s add 17
execute as @a if score @s rand matches 18 run tag @s add 18
execute as @a if score @s rand matches 19 run tag @s add 19
execute as @a if score @s rand matches 21 run tag @s add 21
execute as @a if score @s rand matches 22 run tag @s add 22
execute as @a if score @s rand matches 23 run tag @s add 23
execute as @a if score @s rand matches 24 run tag @s add 24
execute as @a if score @s rand matches 25 run tag @s add 25
execute as @a if score @s rand matches 26 run tag @s add 26
execute as @a if score @s rand matches 27 run tag @s add 27
execute as @a if score @s rand matches 28 run tag @s add 28
execute as @a if score @s rand matches 29 run tag @s add 29
execute as @a if score @s rand matches 30 run tag @s add 30
execute as @a if score @s rand matches 31 run tag @s add 31
execute as @a if score @s rand matches 32 run tag @s add 32
execute as @a if score @s rand matches 33 run tag @s add 33
execute as @a if score @s rand matches 34 run tag @s add 34
execute as @a if score @s rand matches 35 run tag @s add 35
execute as @a if score @s rand matches 36 run tag @s add 36
execute as @a if score @s rand matches 37 run tag @s add 37
execute as @a if score @s rand matches 38 run tag @s add 38
execute as @a if score @s rand matches 39 run tag @s add 39
execute as @a[tag=1] run function cf:effect_1_speed
execute as @a[tag=2] run function cf:effect_2_slowness
execute as @a[tag=3] run function cf:effect_3_haste
execute as @a[tag=4] run function cf:effect_4_mining_fatigue
execute as @a[tag=5] run function cf:effect_5_strength
execute as @a[tag=6] run function cf:effect_6_instant_health
execute as @a[tag=7] run function cf:effect_7_instant_damage
execute as @a[tag=8] run function cf:effect_8_jump_boost
execute as @a[tag=9] run function cf:effect_9_nausea
execute as @a[tag=10] run function cf:effect_10_regeneration
execute as @a[tag=11] run function cf:effect_11_resistance
execute as @a[tag=12] run function cf:effect_12_fire_resistance
execute as @a[tag=13] run function cf:effect_13_water_breathing
execute as @a[tag=14] run function cf:effect_14_invisibility
execute as @a[tag=15] run function cf:effect_15_blindness
execute as @a[tag=16] run function cf:effect_16_night_vision
execute as @a[tag=17] run function cf:effect_17_hunger
execute as @a[tag=18] run function cf:effect_18_weakness
execute as @a[tag=19] run function cf:effect_19_poison
execute as @a[tag=20] run function cf:effect_21_wither
execute as @a[tag=21] run function cf:effect_22_health_boost
execute as @a[tag=22] run function cf:effect_23_absorption
execute as @a[tag=23] run function cf:effect_24_saturation
execute as @a[tag=24] run function cf:effect_25_glowing
execute as @a[tag=25] run function cf:effect_26_levitation
execute as @a[tag=26] run function cf:effect_27_luck
execute as @a[tag=27] run function cf:effect_28_unluck
execute as @a[tag=28] run function cf:effect_29_slow_falling
execute as @a[tag=29] run function cf:effect_30_conduit_power
execute as @a[tag=30] run function cf:effect_31_dolphins_grace
execute as @a[tag=31] run function cf:effect_32_bad_omen
execute as @a[tag=32] run function cf:effect_33_raid_omen
execute as @a[tag=33] run function cf:effect_34_trial_omen
execute as @a[tag=34] run function cf:effect_35_hero_of_the_village
execute as @a[tag=35] run function cf:effect_36_darkness
execute as @a[tag=36] run function cf:effect_37_weaving
execute as @a[tag=37] run function cf:effect_38_wind_charged
execute as @a[tag=38] run function cf:effect_39_infested
execute as @a[tag=39] run function cf:effect_40_oozing
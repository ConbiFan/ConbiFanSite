effect give @a[tag=18] weakness 30 2
schedule function cf:dore 6000t append

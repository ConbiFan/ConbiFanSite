effect give @a[tag=24] glowing 30 2
schedule function cf:dore 300s

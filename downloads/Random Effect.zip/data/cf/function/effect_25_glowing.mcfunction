effect give @a[tag=25] glowing 30 2
schedule function cf:dore 6000t append

effect give @a[tag=32] raid_omen 30 2
schedule function cf:dore 300s

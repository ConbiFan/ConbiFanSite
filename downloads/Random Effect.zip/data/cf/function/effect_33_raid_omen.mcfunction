effect give @a[tag=33] raid_omen 30 2
schedule function cf:dore 6000t append

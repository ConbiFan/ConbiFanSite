effect give @a[tag=27] luck 30 2
schedule function cf:dore 6000t append

effect give @a[tag=15] blindness 30 2
schedule function cf:dore 300s

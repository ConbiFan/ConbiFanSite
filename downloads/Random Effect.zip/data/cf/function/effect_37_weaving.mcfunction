effect give @a[tag=36] weaving 30 2
schedule function cf:dore 300s

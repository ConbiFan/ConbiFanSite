effect give @a[tag=37] weaving 30 2
schedule function cf:dore 6000t append

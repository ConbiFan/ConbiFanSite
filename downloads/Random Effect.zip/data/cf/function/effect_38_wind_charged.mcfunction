effect give @a[tag=38] wind_charged 30 2
schedule function cf:dore 6000t append

effect give @a[tag=37] wind_charged 30 2
schedule function cf:dore 300s

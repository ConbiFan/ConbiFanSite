effect give @a[tag=27] unluck 30 2
schedule function cf:dore 300s

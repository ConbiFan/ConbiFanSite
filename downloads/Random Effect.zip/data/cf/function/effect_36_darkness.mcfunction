effect give @a[tag=35] darkness 30 2
schedule function cf:dore 300s

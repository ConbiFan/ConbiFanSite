effect give @a[tag=8] jump_boost 30 2
schedule function cf:dore 300s

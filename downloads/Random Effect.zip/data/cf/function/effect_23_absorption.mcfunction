effect give @a[tag=23] absorption 30 2
schedule function cf:dore 6000t append

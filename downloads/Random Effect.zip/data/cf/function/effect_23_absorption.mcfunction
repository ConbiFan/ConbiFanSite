effect give @a[tag=22] absorption 30 2
schedule function cf:dore 300s

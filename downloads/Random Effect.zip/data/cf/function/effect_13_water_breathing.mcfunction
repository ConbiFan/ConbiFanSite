effect give @a[tag=13] water_breathing 30 2
schedule function cf:dore 300s

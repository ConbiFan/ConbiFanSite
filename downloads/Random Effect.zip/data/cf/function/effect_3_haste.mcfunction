effect give @a[tag=3] haste 30 2
schedule function cf:dore 6000t append

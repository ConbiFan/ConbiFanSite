scoreboard objectives add rand dummy
scoreboard players set @a rand 0
tellraw @a ["",{"text":"\u8aac\u660e","bold":true,"color":"#FF3A3A"},{"text":"\n\u30e9\u30f3\u30c0\u30e0\u306a\u30a8\u30d5\u30a7\u30af\u30c8\u304c5\u5206\u3054\u3068\u306b\u4ed8\u4e0e\u3055\u308c\u307e\u3059\u3002\n\u30d0\u30d5\u3082\u3042\u308c\u3070\u30c7\u30d0\u30d5\u3082\u3042\u308a\u307e\u3059\u3002"}]
schedule function dore 300s
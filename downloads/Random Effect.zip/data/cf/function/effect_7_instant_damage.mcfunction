effect give @a[tag=7] instant_damage 30 2
schedule function cf:dore 300s append

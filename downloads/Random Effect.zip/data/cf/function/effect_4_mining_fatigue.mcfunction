effect give @a[tag=4] mining_fatigue 30 2
schedule function cf:dore 300s

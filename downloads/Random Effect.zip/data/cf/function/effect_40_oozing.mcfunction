effect give @a[tag=39] oozing 30 2
schedule function cf:dore 300s

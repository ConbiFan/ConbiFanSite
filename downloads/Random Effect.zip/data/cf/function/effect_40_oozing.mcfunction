effect give @a[tag=40] oozing 30 2
schedule function cf:dore 6000t append

effect give @a[tag=10] regeneration 30 2
schedule function cf:dore 300s
effect give @a[tag=28] slow_falling 30 2
schedule function cf:dore 300s

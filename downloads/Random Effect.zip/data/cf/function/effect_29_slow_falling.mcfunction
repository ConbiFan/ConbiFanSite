effect give @a[tag=29] slow_falling 30 2
schedule function cf:dore 6000t append

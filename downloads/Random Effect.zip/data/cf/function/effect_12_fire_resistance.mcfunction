effect give @a[tag=12] fire_resistance 30 2
schedule function cf:dore 6000t append

effect give @a[tag=21] wither 30 2
schedule function cf:dore 6000t append

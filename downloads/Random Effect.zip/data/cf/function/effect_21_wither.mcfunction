effect give @a[tag=20] wither 30 2
schedule function cf:dore 300s

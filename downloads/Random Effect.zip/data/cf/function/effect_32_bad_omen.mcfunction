effect give @a[tag=32] bad_omen 30 2
schedule function cf:dore 6000t append

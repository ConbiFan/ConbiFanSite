effect give @a[tag=31] bad_omen 30 2
schedule function cf:dore 300s

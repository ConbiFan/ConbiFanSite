effect give @a[tag=14] invisibility 30 2
schedule function cf:dore 300s

effect give @a[tag=29] conduit_power 30 2
schedule function cf:dore 300s

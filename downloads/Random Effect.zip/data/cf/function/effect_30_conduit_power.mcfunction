effect give @a[tag=30] conduit_power 30 2
schedule function cf:dore 6000t append

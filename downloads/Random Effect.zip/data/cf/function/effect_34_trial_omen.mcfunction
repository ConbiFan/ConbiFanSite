effect give @a[tag=34] trial_omen 30 2
schedule function cf:dore 6000t append

effect give @a[tag=33] trial_omen 30 2
schedule function cf:dore 300s

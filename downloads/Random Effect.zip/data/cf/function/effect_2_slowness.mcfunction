effect give @a[tag=2] slowness 30 2
schedule function cf:dore 300s

effect give @a[tag=39] infested 30 2
schedule function cf:dore 6000t append

effect give @a[tag=38] infested 30 2
schedule function cf:dore 300s

effect give @a[tag=35] hero_of_the_village 30 2
schedule function cf:dore 6000t append

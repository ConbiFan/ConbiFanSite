effect give @a[tag=34] hero_of_the_village 30 2
schedule function cf:dore 300s

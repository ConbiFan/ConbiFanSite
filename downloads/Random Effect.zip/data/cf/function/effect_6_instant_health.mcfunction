effect give @a[tag=6] instant_health 30 2
schedule function cf:dore 300s

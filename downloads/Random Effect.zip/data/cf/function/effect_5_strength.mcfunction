effect give @a[tag=5] strength 30 2
schedule function cf:dore 300s
